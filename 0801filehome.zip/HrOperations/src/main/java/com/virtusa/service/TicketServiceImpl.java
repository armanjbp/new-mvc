package com.virtusa.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.dao.TicketDAO;
import com.virtusa.model.Ticket;

@Service
@Transactional
public class TicketServiceImpl implements TicketService {

	@Autowired
	private TicketDAO ticketDAO;

	public void addTicket(Ticket ticket) {
		ticketDAO.addTicket(ticket);

	}

	public void updateTicket(Ticket ticket) {
		ticketDAO.updateTicket(ticket);

	}

	public Ticket getTicket(int id) {
		return ticketDAO.getTicket(id);
	}

	public void deleteTicket(int id) {
		ticketDAO.deleteTicket(id);

	}

	public List<Ticket> getTickets() {
		return ticketDAO.getTickets();
	}

}
