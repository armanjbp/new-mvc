package com.virtusa.service;

import java.util.List;

import com.virtusa.model.Ticket;

public interface TicketService {

	public void addTicket(Ticket ticket);
	public void updateTicket(Ticket ticket);
	public Ticket getTicket(int id);
	public void deleteTicket(int id);
	public List<Ticket> getTickets();

}
