package com.virtusa.dao;

import com.virtusa.model.Login;
import com.virtusa.model.User;

public interface UserDao {

  int register(User user);

  User validateUser(Login login);
}
